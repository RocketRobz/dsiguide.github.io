NUS Downloader (NUSD) v1.9
WB3000

This release is intended to be a stable precursor to v2.0

Latest info is always at:
http://wiibrew.org/wiki/NUS_Downloader

Latest databases:
http://wiibrew.org/wiki/NUS_Downloader/database
http://dsibrew.org/wiki/NUS_Downloader/database

Be sure to make changes to the database wikis if you find errors!